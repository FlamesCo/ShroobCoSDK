import pygame

# Overworld system

class Overworld:
    def __init__(self):
        pass

    def update(self):
        pass

    def render(self, screen):
        pass